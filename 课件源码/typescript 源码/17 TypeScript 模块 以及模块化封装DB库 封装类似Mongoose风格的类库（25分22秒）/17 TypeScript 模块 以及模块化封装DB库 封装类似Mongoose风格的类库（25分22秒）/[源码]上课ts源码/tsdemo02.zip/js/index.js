"use strict";
/*
1、vscode配置自动编译

    1.第一步   tsc --inti 生成tsconfig.json   改 "outDir": "./js",


    2、第二步 任务 - 运行任务  监视tsconfig.json


2、typeScript中的数据类型

    typescript中为了使编写的代码更规范，更有利于维护，增加了类型校验，在typescript中主要给我们提供了以下数据类型


        布尔类型（boolean）
        数字类型（number）
        字符串类型(string)
        数组类型（array）
        元组类型（tuple）
        枚举类型（enum）

        任意类型（any）
        null 和 undefined
        void类型
        never类型

3、typeScript中的函数

    3.1、函数的定义
    3.2、可选参数
    3.3、默认参数
    3.4、剩余参数
    3.5、函数重载
    3.6、箭头函数  es6
4、typeScript中的类

    4.1 类的定义
    4.2 继承
    4.3 类里面的修饰符
    4.4 静态属性 静态方法
    4.5 抽象类 多态
5、typeScript中的接口

    5.1 属性类接口
    5.2 函数类型接口
    5.3 可索引接口
    5.4 类类型接口
    5.5 接口扩展

6、typeScript中的泛型

    6.1 泛型的定义
    6.2 泛型函数
    6.3 泛型类
    6.4 泛型接口

7、接口 泛型 泛型类的综合使用


8、模块

   8.1 模块的的概念
   8.2 模块导出的几种方法
        1、export 导出声明
        2、export 导出语句
        3、export default
        4、import导入模块

    8.3 模块化封装上一讲的DB库

*/
Object.defineProperty(exports, "__esModule", { value: true });
/*
    模块的的概念（官方）:

         关于术语的一点说明: 请务必注意一点，TypeScript 1.5里术语名已经发生了变化。 “内部模块”现在称做“命名空间”。
         “外部模块”现在则简称为“模块” 模块在其自身的作用域里执行，而不是在全局作用域里；
         这意味着定义在一个模块里的变量，函数，类等等在模块外部是不可见的，除非你明确地使用export形式之一导出它们。
         相反，如果想使用其它模块导出的变量，函数，类，接口等的时候，你必须要导入它们，可以使用 import形式之一。

    模块的概念（自己理解）：

        我们可以把一些公共的功能单独抽离成一个文件作为一个模块。
        模块里面的变量 函数 类等默认是私有的，如果我们要在外部访问模块里面的数据（变量、函数、类），
        我们需要通过export暴露模块里面的数据（变量、函数、类...）。
        暴露后我们通过 import 引入模块就可以使用模块里面暴露的数据（变量、函数、类...）。

*/
// import { dbUrl,getData} from './modules/db';
// console.log(dbUrl);
// getData();
var db_1 = require("./modules/db");
console.log(db_1.dbUrl);
db_1.getData();
