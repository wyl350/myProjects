
var dbUrl='xxxxxx';


export function getData():any[]{

    console.log('获取数据库的数据111');

    return [

        {

            title:'121312'
        },
        {

            title:'121312'
        }
    ]
}



export function save(){

    console.log('保存数据成功');
}